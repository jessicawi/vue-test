const EN = {
    "Amount": "Setting",
};

export default EN;