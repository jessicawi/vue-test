<template>
    <div id="top-up" class="white-box">
        <span>
            充值金额
        </span>
        <span>
            100
        </span>
    </div>
</template>

<script>
    export default {
        name: 'TopUp',
    };
</script>

<style scoped>
    #step {

    }
</style>
