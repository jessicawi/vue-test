const CN = {
    "Top Up": "充值",
};

export default CN;