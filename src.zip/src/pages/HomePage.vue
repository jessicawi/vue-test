<template>
    <div>
        <!--<Step/>-->
        <div>
            <b>session token:</b> {{token}}<br/><br/>{{userType}}<br/><br/>
            <div v-for="object in list" :key="object.UserIDSession">
                {{object.UserIDSession}}
            </div>

        </div>
    </div>
</template>

<script>
    import Step from "../components/Step";
    import DataSource from "../data/datasource";

    export default {
        name: 'homePage',
        data() {
            return {
                token: null,
                userType: null,
                list: [],
            }
        },
        components: {Step},
        mounted() {
            this.showSession()
            // user menu
            const isParent = sessionStorage.getItem('userTypeSession');
            if (isParent !== "parent") {
                this.results = response;

                // window.location.replace("/");
            }
            let response =  DataSource.shared.getUserMenu();
            this.list = response.Table;
            console.log(response);
        },
        // mounted() {
        //     this.showSession()
        // },
        methods: {
            showSession: async function () {
                this.token = sessionStorage.getItem('authToken') || "no token";
                this.userType = sessionStorage.getItem('userTypeSession');
            }
        }
    };
</script>

<style scoped>

</style>
